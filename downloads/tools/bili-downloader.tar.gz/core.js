// ================================================================
// B站下载器 - 核心逻辑（零 DOM 依赖，可 headless 测试）
// 由 QuickAdd 脚本《B站下载.js》抽取：wbi 签名、view + playurl、
// 官方 CDN 多节点切换（150ms 节流平滑进度条 + EMA 速度）、
// 流复制裁切 + CRF 重编码压缩、转文字（python -c，双引擎：SenseVoice-Small 缺省 /
// faster-whisper 备选，issue 444）。
// 网络函数（fetchJson / https.get）可注入，便于测试。
// ================================================================
const { spawn } = require('child_process')
const crypto = require('crypto')
const https = require('https')
const fs = require('fs')
const os = require('os')
const path = require('path')

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

// ---- B站 web API（wbi 签名）----
const MIXIN_KEY_ENC_TAB = [46, 47, 18, 2, 53, 8, 23, 32, 15, 50, 10, 31, 58, 3, 45, 35, 27, 43, 5, 49, 33, 9, 42, 19, 29, 28, 14, 39, 12, 38, 41, 13, 37, 48, 7, 16, 24, 55, 40, 61, 26, 17, 0, 1, 60, 51, 30, 4, 22, 25, 54, 21, 56, 59, 6, 63, 57, 62, 11, 36, 20, 34, 44, 52]

function getMixinKey(orig) {
  return MIXIN_KEY_ENC_TAB.map(n => orig[n]).join('').slice(0, 32)
}

async function fetchJsonImpl(url, headers = {}) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': UA, ...headers } }, res => {
      let d = ''
      res.on('data', c => (d += c))
      res.on('end', () => {
        try { resolve(JSON.parse(d)) } catch { reject(new Error('API 响应解析失败')) }
      })
    }).on('error', e => reject(new Error(`网络请求失败：${e.message}`)))
  })
}

async function getWbiKeys(cookie, fetchJson) {
  const j = await fetchJson('https://api.bilibili.com/x/web-interface/nav', cookie ? { Cookie: cookie } : {})
  const w = j && j.data && j.data.wbi_img
  if (!w) throw new Error('获取 wbi keys 失败')
  return {
    imgKey: w.img_url.slice(w.img_url.lastIndexOf('/') + 1, w.img_url.lastIndexOf('.')),
    subKey: w.sub_url.slice(w.sub_url.lastIndexOf('/') + 1, w.sub_url.lastIndexOf('.')),
  }
}

function wbiSign(params, imgKey, subKey) {
  const mixinKey = getMixinKey(imgKey + subKey)
  params.wts = Math.round(Date.now() / 1000)
  const qs = Object.keys(params).sort().map(k => `${k}=${encodeURIComponent(params[k])}`).join('&')
  return qs + '&w_rid=' + crypto.createHash('md5').update(qs + mixinKey).digest('hex')
}

async function getViewInfo({ bvid, cookie, fetchJson }) {
  const j = await fetchJson(`https://api.bilibili.com/x/web-interface/view?bvid=${bvid}`, cookie ? { Cookie: cookie } : {})
  if (j.code !== 0) throw new Error(`视频信息获取失败：${j.message || j.code}`)
  const d = j.data
  const pages = Array.isArray(d.pages) && d.pages.length
    ? d.pages.map((p, i) => ({ cid: p.cid, page: p.page != null ? p.page : i + 1, title: p.part || '', duration: p.duration != null ? p.duration : d.duration }))
    : [{ cid: d.cid, page: 1, title: '', duration: d.duration }]
  return {
    title: d.title, uploader: d.owner.name, duration: d.duration,
    thumbnail: d.pic, cid: d.cid, pages,
  }
}

async function getPlayUrls({ bvid, cid, cookie, fetchJson }) {
  const keys = await getWbiKeys(cookie, fetchJson)
  const qs = wbiSign({ bvid, cid, fnval: 4048, fourk: 1, qn: 127, platform: 'pc' }, keys.imgKey, keys.subKey)
  const j = await fetchJson(`https://api.bilibili.com/x/player/wbi/playurl?${qs}`, cookie ? { Cookie: cookie } : {})
  if (j.code !== 0) throw new Error(`播放地址获取失败：${j.message || j.code}`)
  return j.data.dash
}

// ---- UP 主投稿列表（issue 263「每日简报」）----
// x/space/wbi/arc/search（wbi 签名 + Cookie）→ 该 mid 的投稿。相比动态流（x/polymer/web-dynamic/v1/feed/space）：
// 直接给 bvid/created/description，不受动态保留条数限制；length 字段是字符串（"MM:SS"/"HH:MM:SS"）需转秒。
// 返回按接口顺序（order=pubdate 倒序）的 [{bvid,title,pubdate,duration,pic,description}]
async function getUpVideos({ mid, cookie, fetchJson, ps = 10, pn = 1 }) {
  const keys = await getWbiKeys(cookie, fetchJson)
  const qs = wbiSign(
    { mid: String(mid), ps: String(ps), pn: String(pn), order: 'pubdate', tid: '0', order_avoided: 'true' },
    keys.imgKey, keys.subKey,
  )
  const j = await fetchJson(`https://api.bilibili.com/x/space/wbi/arc/search?${qs}`, cookie ? { Cookie: cookie } : {})
  if (j.code !== 0) throw new Error(`投稿列表获取失败：${j.message || j.code}`)
  const vlist = (j.data && j.data.list && j.data.list.vlist) || []
  return vlist.map(v => ({
    bvid: v.bvid || '',
    title: v.title || '',
    pubdate: Number(v.created) || 0,
    duration: parseLenStr(v.length),
    pic: v.pic || '',
    description: v.description || '',
    author: v.author || '',
  })).filter(v => v.bvid)
}

// 投稿列表 length 字段是字符串（"MM:SS" / "HH:MM:SS"）→ 秒；非法返回 0
function parseLenStr(s) {
  const parts = String(s == null ? '' : s).split(':').map(p => Number(p))
  if (!parts.length || parts.some(n => !isFinite(n))) return 0
  return parts.reduce((acc, n) => acc * 60 + n, 0)
}

// 取视频第 1 P 的 cid（x/player/pagelist）。
// 注意：接口 data 为**裸数组**（`data:[{cid,page,…}]`），历史形态 `data.pages[]` 亦兼容。
async function getCid({ bvid, cookie, fetchJson }) {
  const j = await fetchJson(`https://api.bilibili.com/x/player/pagelist?bvid=${encodeURIComponent(bvid)}`, cookie ? { Cookie: cookie } : {})
  if (j.code !== 0) throw new Error(`分P信息获取失败：${j.message || j.code}`)
  const d = j.data
  const pages = Array.isArray(d) ? d : (d && d.pages) || []
  return pages.length ? pages[0].cid : null
}

// ---- 字幕优先链路（issue 263）----
// x/player/v2 → data.subtitle.subtitles[]（中文优先）→ subtitle_url 拉 JSON → body[].content 拼接全文。
// 无字幕 / 接口异常 / 空文本 → 返回 null（调用方回退转写分支）。
// 注意：subtitle_url 形如 `//aisubtitle.hdslb.com/…`（协议相对），必须补 `https:` 前缀才能直连。
//
// **可信度校验（issue 263 实测发现，必须做）**：B 站对部分稿件返回的 AI 字幕与视频**内容不符**——
// 实测 `BV1ZSb36zE9G`（时长 39s、cid 稳定）同一个 cid 两次调用拿到的字幕分别讲「贵阳街头炒菜」（756s 轨）
// 与「重生/小娘子」（138 行），且字幕时间轴远超视频时长。营销号/标题党稿件上尤其常见。
// 因此字幕**不可盲信**：命中后仍须过 checkSubtitlePlausible（时长越界 / 字速不可能 → 判不可信），
// 不可信则**回退音频转写**。getSubtitle 命中但不可信时返回 {text, lang, rejected:'原因'}，调用方据此回退。
async function getSubtitle({ bvid, cid, cookie, fetchJson, duration }) {
  const j = await fetchJson(`https://api.bilibili.com/x/player/v2?bvid=${encodeURIComponent(bvid)}&cid=${encodeURIComponent(cid)}`, cookie ? { Cookie: cookie } : {})
  if (!j || j.code !== 0) return null
  const subs = (j.data && j.data.subtitle && j.data.subtitle.subtitles) || []
  if (!Array.isArray(subs) || !subs.length) return null
  // 中文轨优先：B 站 lan 实际值是 `ai-zh`（AI 中文）/`zh-CN`/`zh-Hans` 等——**不是**以 zh 开头，
  // 因此先精确匹配 ai-zh，再退化为「含 zh」，最后兜底首轨。
  const pick = subs.find(s => /^ai-zh$/i.test((s && s.lan) || ''))
    || subs.find(s => /zh/i.test((s && s.lan) || ''))
    || subs[0]
  let u = String((pick && pick.subtitle_url) || '')
  if (!u) return null
  if (u.indexOf('//') === 0) u = 'https:' + u
  const body = await fetchJson(u, cookie ? { Cookie: cookie } : {})
  const lines = Array.isArray(body && body.body) ? body.body : []
  const segs = lines
    .map(l => ({ text: String((l && l.content) || '').trim(), to: Number(l && l.to) || 0 }))
    .filter(s => s.text)
  const text = segs.map(s => s.text).join(' ')
  if (!text) return null
  const lang = (pick && (pick.lan_doc || pick.lan)) || ''
  const maxTo = segs.reduce((m, s) => Math.max(m, s.to), 0)
  const check = checkSubtitlePlausible({ text, maxTo, duration })
  return check.ok ? { text, lang } : { text, lang, rejected: check.reason }
}

/** 字幕可信度：字幕时长不得显著超出视频时长；字速（字/秒）不得超出人类语速上限。
 *  duration 未知（0）时跳过时长项校验，仅查字速。返回 {ok} 或 {ok:false, reason} */
function checkSubtitlePlausible({ text, maxTo, duration }) {
  const chars = String(text || '').length
  const dur = Number(duration) || 0
  if (dur > 0 && maxTo > dur * 1.25 + 5) {
    return { ok: false, reason: `字幕时间轴 ${Math.round(maxTo)}s 超出视频时长 ${dur}s` }
  }
  const span = dur > 0 ? dur : maxTo
  if (span > 0 && chars / span > 12) {
    return { ok: false, reason: `字速 ${Math.round(chars / span)} 字/秒 不可能（疑字幕与视频不匹配）` }
  }
  return { ok: true }
}

function lastLine(s) {
  const lines = s.trim().split(/\r?\n/)
  return lines[lines.length - 1] || ''
}

function qualityLabel(f) {
  const h = f.height
  const base = h >= 2160 ? '4K' : h >= 1440 ? '2K' : `${h}P`
  return (f.fps || 0) > 30 ? `${base} ${f.fps}帧` : base
}

function sanitizeName(s) {
  return String(s).replace(/[\\/:*?"<>|#^[\]]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 80) || '视频'
}

function extractBv(url) {
  const m = String(url).match(/BV[0-9A-Za-z]{10}/)
  return m ? m[0] : ''
}

const pad2 = n => String(n).padStart(2, '0')

// 恒显小时位：文件名用 `-` 分隔（HH-MM-SS），显示用 `:` 分隔（HH:MM:SS）
function fmtTime(t) {
  const s = Math.max(0, Math.round(t))
  return `${pad2(Math.floor(s / 3600))}-${pad2(Math.floor(s % 3600 / 60))}-${pad2(s % 60)}`
}

function fmtDuration(t) {
  const s = Math.max(0, Math.round(t))
  return `${pad2(Math.floor(s / 3600))}:${pad2(Math.floor(s % 3600 / 60))}:${pad2(s % 60)}`
}

// 保留 1 位小数的秒字符串（ffmpeg 传参用，避免浮点尾巴）
function fmtSec(t) {
  const x = Math.max(0, Math.round((Number(t) || 0) * 10) / 10)
  return String(x)
}

// 解析用户输入的时间：HH:MM:SS.S / MM:SS.S / SS.S / 裸秒 → 秒（1 位小数）；失败返回 null
function parseTimeInput(str) {
  const s = String(str).trim()
  if (!s || !/^-?[\d:.]+$/.test(s)) return null
  const parts = String(s).split(':').map(p => p.trim())
  if (parts.length > 3) return null
  const nums = parts.map(p => { const n = Number(p); return isFinite(n) && n >= 0 ? n : NaN })
  if (nums.some(Number.isNaN)) return null
  let sec
  if (nums.length === 1) sec = nums[0]
  else if (nums.length === 2) sec = nums[0] * 60 + nums[1]
  else sec = nums[0] * 3600 + nums[1] * 60 + nums[2]
  return Math.max(0, Math.round(sec * 10) / 10)
}

function buildFileName({ title, bv, page, trimmed, start, end, duration, compressed, crf }) {
  let name = `${sanitizeName(title)}_${bv}`
  if (page) name += `_${page}`
  if (trimmed && (start > 0 || end < duration)) name += `_clip_${fmtTime(start)}-${fmtTime(end)}`
  if (compressed && crf !== null && crf !== undefined) name += `_crf${crf}`
  return `${name}.mp4`
}

// 解析：view API（标题/封面）+ playurl API（清晰度列表，官方 CDN baseUrl）
async function parseVideo({ url, cookie, fetchJson = fetchJsonImpl }) {
  const bvid = extractBv(url)
  if (!bvid) throw new Error('无法从链接中识别 BV 号')
  const view = await getViewInfo({ bvid, cookie, fetchJson })
  const dash = await getPlayUrls({ bvid, cid: view.cid, cookie, fetchJson })
  const vids = (dash.video || []).filter(v => v.height)
  if (!vids.length) throw new Error('未找到可下载的视频流')
  const best = new Map() // 每个高度保留一个代表格式（avc > hevc > av01）
  for (const v of vids) {
    const score = f => (f.codecs.startsWith('avc') ? 2 : f.codecs.startsWith('hev') ? 1 : 0) * 100 + (f.frameRate || 0)
    if (!best.has(v.height) || score(v) > score(best.get(v.height))) best.set(v.height, v)
  }
  const formats = [...best.values()]
    .sort((a, b) => b.height - a.height)
    .map(f => ({ height: f.height, fps: Math.round(f.frameRate || 0), label: qualityLabel(f) }))
  return {
    title: view.title, uploader: view.uploader, duration: view.duration,
    thumbnail: view.thumbnail, formats, maxHeight: formats[0] ? formats[0].height : 0,
    bvid, cid: view.cid, pages: view.pages,
  }
}

// 下载：自研 playurl + 多 CDN 节点切换（baseUrl → backupUrl 逐个尝试，慢节点自动跳过）
function fmtEta(sec) {
  if (!isFinite(sec) || sec < 0) return '?'
  sec = Math.round(sec)
  return `${String(Math.floor(sec / 60)).padStart(2, '0')}:${String(sec % 60).padStart(2, '0')}`
}

// 下载单个流：顺序尝试候选 URL；切换条件 = 连接失败 / 非 2xx / 长时间零字节(stall)。
// 慢速但持续有数据的节点不切换（慢 ≠ 失败，只要在动就让它下完）。
// 进度：总大小优先取传入 size，其次取响应 Content-Length；都没有时 percent 为 null（前端显示不确定进度 + 已下载字节）。
function downloadStream({ urls, outPath, referer, size, stallMs = 12000, onProgress, onDiag, get = https.get }) {
  return new Promise((resolve, reject) => {
    const cands = [...urls]
    let idx = 0
    // 跨节点累计的下载量（进度平滑，换节点不回跳；文件本身每次整下用一个节点）
    let received = 0, speed = 0, lastT = Date.now(), lastB = 0, totalBytes = size > 0 ? size : 0
    // 最近一次「本节点没收全」的字节数：全部节点都收不全时，用它给出比「网络受限」更准的失败原因
    let lastShort = null
    const tryNext = () => {
      if (ABORTED) return reject(new Error('已中止'))
      if (idx >= cands.length) {
        return reject(lastShort
          ? new Error(`下载不完整（${lastShort.got}/${lastShort.need} 字节，已重试所有节点）`)
          : new Error('所有 CDN 节点均失败（可能网络受限）'))
      }
      const url = cands[idx++]
      const host = new URL(url).hostname
      onDiag && onDiag(`节点 ${host}`)
      const t0 = Date.now()
      let lastDataAt = 0, settled = false, lastReportAt = 0, contentLength = 0
      let nodeReceived = 0   // 本节点已收字节（received 是跨节点累计，判完整性只能用本节点的）
      const ws = fs.createWriteStream(outPath)
      const h = { req: null, ws }
      trackDownload(h)
      const report = () => {
        const now = Date.now()
        const dt = (now - lastT) / 1000
        const inst = dt > 0 ? (received - lastB) / 1048576 / dt : 0
        speed = speed ? speed * 0.6 + inst * 0.4 : inst   // EMA 平滑瞬时速度，避免数字跳动
        lastT = now; lastB = received
        const known = totalBytes > 0
        onProgress && onProgress({
          phase: 'download',
          percent: known ? Math.min(100, (received / totalBytes) * 100) : null,
          received, total: known ? totalBytes : 0,
          speed: `${speed.toFixed(1)}MiB/s`,
          eta: known ? fmtEta((totalBytes - received) / 1048576 / (speed || 0.01)) : '',
        })
      }
      const stallTimer = setInterval(() => {
        if (settled) return clearInterval(stallTimer)
        report()   // 兜底更新（即使零字节也让前端看到速度在动，慢 ≠ 卡死）
        const idleFor = Date.now() - (lastDataAt || t0)
        if (idleFor > stallMs) {   // 长时间没有任何字节 → 判定死节点，再换一个
          settled = true
          req.destroy()
          ws.destroy()
          onDiag && onDiag(`节点 ${host} 长时间无数据，切换…`)
          tryNext()
        }
      }, 1000)
      const req = get(url, { headers: { 'User-Agent': UA, Referer: referer } }, res => {
        if (res.statusCode !== 200 && res.statusCode !== 206) {
          res.resume()
          settled = true
          clearInterval(stallTimer)
          ws.destroy()
          return tryNext()
        }
        // size 缺失时用 Content-Length 当总大小（真实，不再用 received*4 的 25% 假进度）
        if (res.headers) {
          const cl = parseInt(res.headers['content-length'], 10)
          if (cl > 0) {
            contentLength = cl
            if (totalBytes <= 0) totalBytes = cl
          }
        }
        res.on('data', c => {
          received += c.length
          nodeReceived += c.length
          lastDataAt = Date.now()
          ws.write(c)
          const now = Date.now()
          if (now - lastReportAt >= 150) { lastReportAt = now; report() }   // 150ms 节流高频更新，进度条流畅
        })
        res.on('end', () => {
          if (settled) return
          // 完整性校验（2026-11-08 review）：响应体没收全，别当成品交出去——先换下一个节点整下，
          // 全部节点都收不全才失败。拿不到声明大小（分块传输）时不校验，保持原行为。
          const got = nodeReceived
          const need = contentLength > 0 ? contentLength : (size > 0 ? size : 0)
          if (need > 0 && got < need) {
            settled = true
            clearInterval(stallTimer)
            DOWNLOADS.delete(h)
            lastShort = { got, need }
            onDiag && onDiag(`节点 ${host} 下载不完整（${got}/${need} 字节），切换…`)
            // 等流关闭再切：同一路径会被下一个节点重新整下，避免两个写入流抢同一个文件
            ws.end(() => tryNext())
            return
          }
          settled = true
          clearInterval(stallTimer)
          DOWNLOADS.delete(h)
          const known = totalBytes > 0
          // end 回调：等数据全部 flush 落盘后再 resolve（否则调用方立即读文件会读到不完整内容）
          ws.end(() => {
            onProgress && onProgress({ phase: 'download', percent: known ? Math.min(100, (received / totalBytes) * 100) : null, received, total: known ? totalBytes : received, speed: '✅', eta: '' })
            resolve()
          })
        })
        res.on('error', () => {
          if (settled) return
          settled = true
          clearInterval(stallTimer)
          ws.destroy()
          tryNext()
        })
      })
      h.req = req   // 注册请求句柄，取消任务时可 destroy 中止
      req.on('error', () => {
        if (settled) return
        settled = true
        clearInterval(stallTimer)
        ws.destroy()
        onDiag && onDiag(`节点 ${host} 连接失败，切换…`)
        tryNext()
      })
    }
    tryNext()
  })
}

// 合并音视频（-c copy 秒级）
function mergeStreams({ videoPath, audioPath, outPath, ffmpeg = 'ffmpeg' }) {
  return new Promise((resolve, reject) => {
    const p = spawn(ffmpeg, ['-y', '-i', videoPath, '-i', audioPath, '-c', 'copy', '-movflags', '+faststart', outPath], { windowsHide: true })
    trackProc(p)
    let err = ''
    p.stderr.on('data', d => (err += d))
    p.on('error', e => reject(new Error(`无法启动 ffmpeg：${e.message}`)))
    p.on('close', code => {
      if (code !== 0) reject(new Error(lastLine(err) || `ffmpeg 退出码 ${code}`))
      else resolve()
    })
  })
}

async function downloadVideo({ url, cookie, height, outPath, cid, onProgress, onDiag, ffmpeg = 'ffmpeg', fetchJson = fetchJsonImpl, get = https.get }) {
  const bvid = extractBv(url)
  // 支持分P下载：给 cid 则直接取该 P 播放地址，省一次 view 请求
  const playCid = cid || (await getViewInfo({ bvid, cookie, fetchJson })).cid
  const dash = await getPlayUrls({ bvid, cid: playCid, cookie, fetchJson })
  const vids = (dash.video || []).filter(v => v.height)
  if (!vids.length) throw new Error('未找到可下载的视频流')
  // 目标清晰度：<= height 的最高，avc 优先；找不到则用已有最低
  let v = vids.filter(f => f.height <= height && f.codecs.startsWith('avc')).sort((a, b) => b.height - a.height)[0]
  if (!v) v = vids.filter(f => f.height <= height).sort((a, b) => b.height - a.height)[0]
  if (!v) v = vids.sort((a, b) => b.height - a.height)[0]
  const a = (dash.audio || [])[0]
  if (!a) throw new Error('未找到音频流')
  const tmpV = outPath + '.v.part'
  const tmpA = outPath + '.a.part'
  const referer = `https://www.bilibili.com/video/${bvid}`
  // 音视频总进度聚合：两流累计字节相加；总大小 = API size 或响应 Content-Length（实时补全）。
  // 都拿不到时 percent=null，前端显示不确定进度 + 已下载字节（绝不假报固定百分比）。
  const vMeta = { recv: 0, total: 0 }, aMeta = { recv: 0, total: 0 }
  const agg = key => p => {
    const m = key === 'v' ? vMeta : aMeta
    if (p.received !== undefined) m.recv = p.received
    if (p.total > 0) m.total = p.total
    const got = vMeta.recv + aMeta.recv
    const tot = (vMeta.total || vMeta.recv) + (aMeta.total || aMeta.recv)
    onProgress && onProgress({ phase: 'download', percent: tot > 0 ? Math.min(100, (got / tot) * 100) : null, received: got, total: tot, speed: p.speed, eta: p.eta })
  }
  onDiag && onDiag(`视频流 ${v.height}P（${v.codecs}）`)
  await downloadStream({ urls: [v.baseUrl, ...(v.backupUrl || [])], outPath: tmpV, referer, size: v.size, onProgress: agg('v'), onDiag, get })
  onDiag && onDiag(`音频流 ${a.size ? (a.size / 1048576).toFixed(1) + 'MB' : ''}`)
  await downloadStream({ urls: [a.baseUrl, ...(a.backupUrl || [])], outPath: tmpA, referer, size: a.size, onProgress: agg('a'), onDiag, get })
  onDiag && onDiag('合并音视频…')
  onProgress && onProgress({ phase: 'merge' })
  await mergeStreams({ videoPath: tmpV, audioPath: tmpA, outPath, ffmpeg })
  try { fs.unlinkSync(tmpV) } catch {}
  try { fs.unlinkSync(tmpA) } catch {}
}

// ---- 裁切参数构造（纯函数，可 headless 测试）----
// mode: 'copy'（快速无损：-ss 在 -i 前做输入级 seek + -t 相对时长）
//       | 'reencode'（帧精确：-ss/-to 在 -i 后做输出级切帧）
// 不用输入级 -to（不同 ffmpeg 版本语义有差异，长视频易出短/坏产物 → bug #5）
function buildTrimArgs({ mode, inPath, outPath, start, end, crf = 23, faststartMaxSec = 1800 }) {
  const dur = Math.max(0, end - start)
  const faststart = dur <= faststartMaxSec ? ['-movflags', '+faststart'] : []
  if (mode !== 'reencode') {
    return ['-y', '-ss', fmtSec(start), '-i', inPath, '-t', fmtSec(dur), '-c', 'copy', ...faststart, '-stats_period', '0.2', outPath]
  }
  return ['-y', '-i', inPath, '-ss', fmtSec(start), '-to', fmtSec(end), '-c:v', 'libx264', '-crf', String(crf), '-preset', 'medium', '-c:a', 'aac', ...faststart, '-stats_period', '0.2', outPath]
}

// 执行 ffmpeg：解析 stderr 的 time=HH:MM:SS 做进度；返回 { ok, err }
function runFfmpeg({ args, ffmpeg = 'ffmpeg', totalMs = 0, onProgress }) {
  return new Promise((resolve, reject) => {
    const p = spawn(ffmpeg, args, { windowsHide: true })
    trackProc(p)
    let err = ''
    p.stderr.on('data', d => {
      err += d
      const re = /time=(\d+):(\d+):([\d.]+)/g
      let m
      while ((m = re.exec(String(d))) !== null) {
        const t = (+m[1]) * 3600 + (+m[2]) * 60 + parseFloat(m[3])
        if (totalMs > 0) onProgress && onProgress({ percent: Math.min(100, (t * 1000 / totalMs) * 100) })
      }
    })
    p.on('error', e => reject(new Error(`无法启动 ffmpeg：${e.message}`)))
    p.on('close', code => resolve({ ok: code === 0, err: lastLine(err) || `ffmpeg 退出码 ${code}` }))
  })
}

// ffprobe 读取时长（秒）；失败返回 null
function probeDuration(file, ffprobe = 'ffprobe') {
  return new Promise(resolve => {
    const p = spawn(ffprobe, ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', file], { windowsHide: true })
    trackProc(p)
    let out = ''
    p.stdout.on('data', d => (out += d))
    p.on('error', () => resolve(null))
    p.on('close', code => {
      const n = parseFloat(out.trim())
      resolve(code === 0 && isFinite(n) && n > 0 ? n : null)
    })
  })
}

// 产物校验：能读出时长且在容差内（copy 路径容忍关键帧吸附偏长）
async function validateClip(file, { expectedSec, toleranceSec = 2, ffprobe = 'ffprobe' }) {
  const dur = await probeDuration(file, ffprobe)
  if (dur === null) return { ok: false, dur: null, reason: '无法读取产物' }
  return { ok: Math.abs(dur - expectedSec) <= toleranceSec, dur, reason: `时长 ${dur.toFixed(1)}s 与期望 ${expectedSec.toFixed(1)}s 偏差超限` }
}

// 裁切+压缩：crf 为 null 用流复制（快速无损），否则 libx264 重编码。
// 可靠性保障（bug #5）：copy 产物 ffprobe 校验，失败/时长不符自动重编码重试，保证可播。
// 失败文案以**校验原因**为主：runFfmpeg 无论成败都把 stderr 尾行存进 err，ffmpeg 正常收尾时
// 那行是 aac 的 `Qavg:` 统计——直接拿它当错误原因会把「时长偏差超限」这类真实原因顶掉。
// 返回 { mode: 'copy'|'reencode', reencoded }；失败抛错。
async function trimVideo({ inPath, outPath, ffmpeg = 'ffmpeg', ffprobe = 'ffprobe', start, end, crf, totalMs, onProgress, faststartMaxSec = 1800 }) {
  const dur = Math.max(0, end - start)
  if (crf === null || crf === undefined) {
    let r = await runFfmpeg({ args: buildTrimArgs({ mode: 'copy', inPath, outPath, start, end, faststartMaxSec }), ffmpeg, totalMs, onProgress })
    let copyReason = ''
    if (r.ok) {
      const v = await validateClip(outPath, { expectedSec: dur, toleranceSec: 2, ffprobe })
      if (v.ok) return { mode: 'copy', reencoded: false }
      copyReason = v.reason
    }
    // copy 产物失效/时长不对 → 自动重编码（帧精确，默认 CRF 23）
    try { fs.unlinkSync(outPath) } catch {}
    const r2 = await runFfmpeg({ args: buildTrimArgs({ mode: 'reencode', inPath, outPath, start, end, crf: 23, faststartMaxSec }), ffmpeg, totalMs, onProgress })
    let reReason = ''
    if (r2.ok) {
      const v2 = await validateClip(outPath, { expectedSec: dur, toleranceSec: 0.5, ffprobe })
      if (v2.ok) return { mode: 'reencode', reencoded: true }
      reReason = v2.reason
    }
    const reasons = [copyReason || (r.ok ? '' : r.err), reReason || (r2.ok ? '' : r2.err)].filter(Boolean)
    throw new Error(`裁切失败:${reasons.join('；') || '产物校验未通过'}`)
  }
  const r3 = await runFfmpeg({ args: buildTrimArgs({ mode: 'reencode', inPath, outPath, start, end, crf, faststartMaxSec }), ffmpeg, totalMs, onProgress })
  if (r3.ok) {
    const v3 = await validateClip(outPath, { expectedSec: dur, toleranceSec: 0.5, ffprobe })
    if (v3.ok) return { mode: 'reencode', reencoded: false }
    throw new Error(`压缩失败:${v3.reason}`)
  }
  throw new Error(`压缩失败:${r3.err || '产物校验未通过'}`)
}

// 压缩回退判定：压缩件体积严格大于压缩输入 → 压缩无收益，回退沿用输入（stat 异常保守采纳压缩件）
function needsCompressFallback(inPath, outPath) {
  try { return fs.statSync(outPath).size > fs.statSync(inPath).size } catch { return false }
}

// ---- 合并参数构造（纯函数）----
function buildMergeArgs({ mode, listPath, outPath, crf = 23, faststart = false }) {
  const header = ['-y', '-f', 'concat', '-safe', '0', '-i', listPath]
  const fsOpts = faststart ? ['-movflags', '+faststart'] : []
  if (mode !== 'reencode') return [...header, '-c', 'copy', ...fsOpts, outPath]
  return [...header, '-c:v', 'libx264', '-crf', String(crf), '-preset', 'medium', '-c:a', 'aac', ...fsOpts, outPath]
}

// concat 列表（ffmpeg concat demuxer 语法，转义单引号）
function writeConcatList(listPath, files) {
  const body = files.map(f => `file '${String(f).replace(/'/g, "'\\''")}'`).join('\n') + '\n'
  fs.writeFileSync(listPath, body)
}

// 合并多段：-c copy 拼接优先，产物校验不过 → 重编码拼接（帧精确、兼容异源）。
// 返回 { mode: 'copy'|'reencode' }；失败抛错。
async function mergeSegments({ files, outPath, ffmpeg = 'ffmpeg', ffprobe = 'ffprobe', expectedSec, crf, onProgress, faststartMaxSec = 1800 }) {
  const listPath = outPath + '.concat'
  writeConcatList(listPath, files)
  const faststart = expectedSec <= faststartMaxSec
  let r = await runFfmpeg({ args: buildMergeArgs({ mode: 'copy', listPath, outPath, faststart }), ffmpeg, totalMs: expectedSec * 1000, onProgress })
  if (r.ok && (await validateClip(outPath, { expectedSec, toleranceSec: 2, ffprobe })).ok) { try { fs.unlinkSync(listPath) } catch {}; return { mode: 'copy' } }
  try { fs.unlinkSync(outPath) } catch {}
  const r2 = await runFfmpeg({ args: buildMergeArgs({ mode: 'reencode', listPath, outPath, crf: crf ?? 23, faststart }), ffmpeg, totalMs: expectedSec * 1000, onProgress })
  try { fs.unlinkSync(listPath) } catch {}
  if (r2.ok && (await validateClip(outPath, { expectedSec, toleranceSec: 0.5, ffprobe })).ok) return { mode: 'reencode' }
  throw new Error(`合并失败:${[r.err, r2.err].filter(Boolean).join('；') || '产物校验未通过'}`)
}

// ---- 任务中止追踪（取消时 kill 子进程 + 中断下载流）----
const PROCS = new Set()        // 进行中的 ffmpeg / python 子进程
const DOWNLOADS = new Set()    // 进行中的下载请求 { req, ws }
let ABORTED = false            // 全局中止标志（downloadStream 的 tryNext 检查）
function trackProc(p) { PROCS.add(p); p.on('close', () => PROCS.delete(p)) }
function trackDownload(h) { DOWNLOADS.add(h) }
function abortAll() {
  ABORTED = true
  PROCS.forEach(p => { try { p.kill() } catch {} })
  DOWNLOADS.forEach(h => {
    try { h.req && h.req.destroy() } catch {}
    try { h.ws && h.ws.destroy() } catch {}
  })
  PROCS.clear(); DOWNLOADS.clear()
}
function resetAbort() { ABORTED = false }

// ---- 通用 JSON / 文件工具 ----
function loadCookies(file) {
  try {
    const c = JSON.parse(fs.readFileSync(file, 'utf8'))
    return typeof c.cookie === 'string' && c.cookie.trim() ? c.cookie.trim() : null
  } catch { return null }
}

function saveCookies(file, str) {
  fs.mkdirSync(path.dirname(file), { recursive: true })
  fs.writeFileSync(file, JSON.stringify({ cookie: str.trim(), savedAt: new Date().toISOString() }, null, 2))
}

function readJson(file, def) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')) } catch { return def }
}

function writeJson(file, obj) {
  fs.mkdirSync(path.dirname(file), { recursive: true })
  fs.writeFileSync(file, JSON.stringify(obj, null, 2))
}

// 重名加序号：xxx.mp4 已存在 → xxx_2.mp4
function uniquePath(file) {
  if (!fs.existsSync(file)) return file
  const ext = path.extname(file)
  const base = file.slice(0, -ext.length)
  for (let i = 2; ; i++) {
    const cand = `${base}_${i}${ext}`
    if (!fs.existsSync(cand)) return cand
  }
}

// 内嵌转录 Python 代码（faster-whisper，python -c 执行，无需独立脚本文件）
// 用法: python -c "此代码" <模型> <文件1> [<文件2>...]
// 单进程单次加载模型，依次转录多个文件；**逐段输出**（每段识别完立即 flush）：
//   \x1e<文件路径>\x1f<该段文本>\x1f\n（\x1e/\x1f 为单元分隔符，服务端解析聚合）
//   同一文件多行 = 该文件的多个片段；文件末尾输出空文本行作为**完成哨兵**：
//   \x1e<文件路径>\x1f\x1f\n（不产生文本，服务端据此报「第 i/N 个文件完成」）
// 逐段 flush 的意义：长视频不再等整片识别完才蹦出全部文本，前端可实时看到文字在动（ticket 117）。
const PY_TRANSCRIBE = `
import sys
from faster_whisper import WhisperModel
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding='utf-8')
    except Exception:
        pass
model = WhisperModel(sys.argv[1], device='cpu', compute_type='int8')
for f in sys.argv[2:]:
    # 本机 faster-whisper 的 vad_filter=True(Silero VAD) 会死锁卡死，禁用之（实测 3s 音频 3.6s 完成、无 VAD 亦正常）
    segments, _ = model.transcribe(f, language='zh', vad_filter=False)
    for seg in segments:
        t = (seg.text or '').strip()
        if t:
            sys.stdout.write('\\x1e' + f + '\\x1f' + t + '\\x1f\\n')
            sys.stdout.flush()
    sys.stdout.write('\\x1e' + f + '\\x1f' + '\\x1f\\n')
    sys.stdout.flush()
`

// 内嵌转录 Python 代码（SenseVoice-Small 分支，issue 444）：funasr AutoModel 一次加载、
// 逐文件整段转录（SenseVoice 无流式分段——单文件单段输出，完成哨兵协议与 faster-whisper 一致）。
// argv 布局与 PY_TRANSCRIBE 相同（argv[1] = 档位占位，SenseVoice 模型固定 iic/SenseVoiceSmall，
// 忽略之——保两引擎 spawn 参数形状一致，插件/测试打桩零分叉）。
// 输出文本须清洗 SenseVoice 的富标签（<|zh|><|NEUTRAL|><|Speech|><|woitn|> 等语言/情感/事件标记）。
const PY_TRANSCRIBE_SENSEVOICE = `
import sys, re
from funasr import AutoModel
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding='utf-8')
    except Exception:
        pass
model = AutoModel(model='iic/SenseVoiceSmall', disable_update=True, device='cpu')
for f in sys.argv[2:]:
    try:
        res = model.generate(input=f, language='zh', use_itn=True)
        text = str((res and res[0] and res[0].get('text')) or '')
    except Exception as e:
        sys.stderr.write(str(e) + '\\n')
        text = ''
    # 去掉 <|zh|><|NEUTRAL|> 这类富标签再交付（正则吃掉所有 <|...|> 形态标记）
    text = re.sub(r'<\\|[^>]*\\|>', '', text).strip()
    if text:
        sys.stdout.write('\\x1e' + f + '\\x1f' + text + '\\x1f\\n')
        sys.stdout.flush()
    sys.stdout.write('\\x1e' + f + '\\x1f' + '\\x1f\\n')
    sys.stdout.flush()
`

// 引擎决议（issue 444）：'faster-whisper' 之外的任何值（含 rc 留空）都走缺省 SenseVoice——
// 插件恒下发 engine，rc 键只服务手动 CLI 场景
function resolveEngine(raw) {
  return String(raw || '').trim() === 'faster-whisper' ? 'faster-whisper' : 'sensevoice'
}

// 解析逐文件转录输出（行格式 \x1e<file>\x1f<text>\x1f）；同文件多行聚合为一条；
// 文件结束空行哨兵（\x1e<file>\x1f\x1f）只标记完成、不贡献文本。按输出序返回 [{file, text}]
function parseTranscriptUnits(raw) {
  const out = []
  const byFile = new Map()
  for (const line of String(raw || '').split(/\r?\n/)) {
    if (!line.startsWith('\x1e')) continue
    const rest = line.slice(1)
    const sep = rest.indexOf('\x1f')
    if (sep < 0) continue
    const file = rest.slice(0, sep)
    let text = rest.slice(sep + 1)
    if (text.endsWith('\x1f')) text = text.slice(0, -1)
    if (!file) continue
    text = text.trim()
    if (!text) continue   // 完成哨兵：不计文本
    const prev = byFile.get(file)
    if (prev) prev.text = prev.text ? prev.text + ' ' + text : text
    else { const u = { file, text }; byFile.set(file, u); out.push(u) }
  }
  return out
}

// 转文字：python -c 执行内嵌代码；stdout 逐块回调（修复原版双监听导致的文本双写）。
// engine（issue 444）：'faster-whisper' → PY_TRANSCRIBE；其余（缺省）→ PY_TRANSCRIBE_SENSEVOICE。
// args 形状两引擎一致：[档位, 文件…]（SenseVoice 忽略档位占位）。
// 模型缓存目录（可选）：填了 → 转写子进程注入 MODELSCOPE_CACHE / HF_HOME（只对这一枪生效，
// 不改系统环境变量）；留空 → 返回空对象，跟随该 Python 的环境默认（~/.cache/modelscope、~/.cache/huggingface）
function modelCacheEnv(modelsDir) {
  const d = String(modelsDir || '').trim()
  if (!d) return {}
  return {
    MODELSCOPE_CACHE: path.join(d, 'modelscope'),
    HF_HOME: path.join(d, 'huggingface'),
  }
}

function runPython({ py, engine, args, onChunk, modelsDir }) {
  const script = resolveEngine(engine) === 'faster-whisper' ? PY_TRANSCRIBE : PY_TRANSCRIBE_SENSEVOICE
  return new Promise((resolve, reject) => {
    const p = spawn(py, ['-c', script, ...args], { windowsHide: true, env: { ...process.env, ...modelCacheEnv(modelsDir), PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' } })
    trackProc(p)   // 取消任务时可 kill 中止转录
    let err = ''
    p.stdout.on('data', d => { const s = String(d); onChunk && onChunk(s) })
    p.stderr.on('data', d => { err += d })
    p.on('error', e => reject(new Error(`无法启动 Python：${e.message}`)))
    p.on('close', code => { if (code !== 0) reject(new Error(lastLine(err) || `Python 退出码 ${code}`)); else resolve() })
  })
}

// ---- 视频缓存（F1）：只缓存「下载原件」，键 = BV + cid(分P) + 清晰度 ----
function cacheKey(bv, cid, quality) {
  return `${bv}_${cid}_${quality}`
}

// 缓存目录：rc cacheDir 可选，缺省系统临时目录下 bili-dl-cache
function getCacheDir(conf) {
  return (conf && conf.cacheDir) ? conf.cacheDir : path.join(os.tmpdir(), 'bili-dl-cache')
}

function cachePath(conf, key) {
  return path.join(getCacheDir(conf), `${key}.mp4`)
}

// 启动清扫：删除超过 cacheRetentionDays（默认 7）天的缓存原件与断点续跑产物；返回删除数
function cleanupCache(conf, now = Date.now()) {
  const dir = getCacheDir(conf)
  let files = []
  try { files = fs.readdirSync(dir).filter(f => f.endsWith('.mp4') || f.startsWith('resume-')) } catch { return 0 }
  if (!files.length) return 0
  const maxAge = Math.max(0, Number((conf && conf.cacheRetentionDays) || 7)) * 86400000
  let removed = 0
  for (const f of files) {
    const p = path.join(dir, f)
    try { if (now - fs.statSync(p).mtimeMs > maxAge) { fs.unlinkSync(p); removed++ } } catch {}
  }
  return removed
}

// ---- 断点续跑产物缓存（ADR-0067 用户拍板：重试从出错步骤继续，成功步骤产物留存复用）----
// ticket 136 起只留机械产物（剪辑件/压缩件/转写稿），AI 元数据/润色分块缓存随 AI 回迁 bz 插件而移除。
// 键 = BV + cid(分P) + 起止范围（0.1s 精度，整片 = 0-duration）；文件放 cacheDir（cleanupCache 同保留期回收）。
function resumeKey(bv, cid, s, e) {
  const bit = n => String(Math.round((Number(n) || 0) * 10))
  return `${bv}_${cid}_${bit(s)}-${bit(e)}`
}
function resumeClipPath(conf, bv, cid, height, s, e) {
  return path.join(getCacheDir(conf), `resume-clip-${resumeKey(bv, cid, s, e)}-${height}.mp4`)
}
function resumeCompressedPath(conf, bv, cid, crf, s, e) {
  return path.join(getCacheDir(conf), `resume-compress-${resumeKey(bv, cid, s, e)}-crf${crf}.mp4`)
}
function resumeTranscriptPath(conf, bv, cid, s, e) {
  return path.join(getCacheDir(conf), `resume-transcript-${resumeKey(bv, cid, s, e)}.txt`)
}





// ---- 无头批处理（--batch）：runBatch ----
// 契约（与 Obsidian 插件「文献盒」面板对齐，cli.js --batch 调用；ticket 136 起 AI/文献笔记回迁 bz）：
// 插件经 shell 启动（.cmd shim 需 shell:true）时 JSON 的引号/空格会被 cmd 对消破坏，故传 `b64:<base64>`；
// 手动命令行 `--batch '<json>'` 直传 JSON 照常支持（decodeBatchArg 二者皆收，P2-5）。
//   task = { url, start, end, page, options }；start/end 为 'HH:MM:SS(.S)'/'MM:SS'/秒 或 null；都 null = 整片不剪辑。
//   task.page（可选，ADR-0067 添加界面分P选择）：1 起的分P 序号，越界/缺省 = 第 1 P（按 P 独立缓存键）。
//   task.options（bz「文献盒」设置全量下发，全部可选）：quality='720'|'1080'|'highest'（缺省最高）、
//     keepVideo=false 跳过交付（video 结果 null）、outputDir 覆盖交付目录（空跟随 conf.outputDir）、
//     compress=false 关闭压缩（缺省开，用户拍板）、crf=18-28（缺省 23）、vaultPath/ffmpegPath/ffprobePath/
//     pythonPath/whisperModel/cacheDir/cacheRetentionDays（缺省跟随 conf / rc 兜底）、
//     engine='sensevoice'（缺省）|'faster-whisper'（issue 444，插件恒下发；whisperModel 档位仅
//     faster-whisper 引擎消费，SenseVoice 模型固定无档位）。
//   deps（全部可注入，防循环依赖——core 不 require config.js，conf 由调用方读入传入）：
//     conf（必需：vaultPath/outputDir/cacheDir/ffmpegPath/ffprobePath/pythonPath/whisperModel/engine）、
//     cookie、fetchJson/get（网络注入，测试打桩）、ffmpeg、ffprobe、py、
//     runPythonImpl（转录打桩）、onStep(名称)、onProgress(进度)、onInfo(解析信息 {title,uploader,bvid,url,duration})、tmpDir。
// 步骤时序：resetAbort → 解析 → 下载（缓存命中检测与回写）→ 剪辑（起止有值才跑）→ 压缩（缺省开，crf 重编码）
//   → 转文字（runPython + PY_TRANSCRIBE，parseTranscriptUnits 收文本）→ 写转录临时文件 → 交付（keepVideo 才跑）。
//   **不再写文献笔记**（AI 与笔记落盘由 bz 插件完成）。
// 进度：onProgress({phase:'download'|'trim'|'compress'|'transcribe', pct})，pct 为 0-100 或 null（不确定，绝不假报）；
//   300ms 节流聚合高频事件。步骤行 onStep 覆盖：解析中/下载中/剪辑中/压缩中/转文字中/交付中。
// 断点续跑（ADR-0067，ticket 136 缩减为机械产物）：剪辑件/压缩件/转写稿留存 cacheDir（resume-*），
//   重跑自动跳过已完成步骤；AI 元数据/润色分块缓存已随 AI 回迁移除。cleanupCache 同保留期回收。
// 返回 { transcript, video, transcriptPath, videoPath, title, bvid, duration }：
//   transcript = 转录临时文件**绝对路径**（UTF-8 全文，插件读取后自删）；video = vault 相对/绝对 或 null（未交付）。
//   任一步失败抛错（中文文案带缺失前置引导）。
/**
 * 解析 --batch 参数（P2-5）：`b64:` 前缀 = base64 编码的 JSON（插件经 shell（.cmd shim）启动时
 * JSON 引号/空格被 shell 对消破坏——Windows cmd 实测 argv 变 `{\"…` 报 position 1 JSON 错；
 * base64 无引号无空格，shell 全程安全）；否则按 JSON 直解析（手动命令行）。
 * 抛错沿用 JSON.parse 原生错误（cli.js 包中文前缀）。
 */
function decodeBatchArg(raw) {
  if (typeof raw === 'string' && raw.indexOf('b64:') === 0) {
    return JSON.parse(Buffer.from(raw.slice(4), 'base64').toString('utf8'))
  }
  return JSON.parse(raw)
}

function vaultRel(absPath, vaultPath) {
  if (!vaultPath) return absPath
  const vaultAbs = path.resolve(vaultPath)
  const rel = path.relative(vaultAbs, absPath)
  if (rel && !rel.startsWith('..') && !path.isAbsolute(rel)) return rel.replace(/\\/g, '/')
  return absPath
}

// ---- 本地音视频（ADR-0296：--batch 的 task.local 分支）----
// 本机文件不下载、不动视频本体：先 ffmpeg 抽 16k 单声道 wav（视频取音轨 / 音声转码），
// 有起止就顺带按段切；再走同一套 Python 转写；最后按 keepVideo 决定是否把原件复制进交付目录。
// 返回形状与 runBatch 一致（transcript/video/transcriptPath/videoPath/title/duration），插件侧零分叉。
//
// 不做断点续跑缓存：本机文件没有「下载」这一大段时间，重跑最多重抽一次音轨；键怎么设计
// （路径 + mtime + 起止）比省下来的几十秒贵，先不做。文件被移走/删除时每次都会当场报错。

/** 抽 16k 单声道 wav（start/end 有值 = 按段切；音频没有关键帧问题，用输出级精确切） */
async function extractAudio({ inPath, outPath, ffmpeg = 'ffmpeg', start = 0, end = 0, totalMs = 0, onProgress }) {
  const args = ['-y', '-i', inPath, '-vn', '-ac', '1', '-ar', '16000']
  if (start > 0 || end > 0) args.push('-ss', fmtSec(start), '-to', fmtSec(end))
  args.push('-c:a', 'pcm_s16le', '-f', 'wav', '-stats_period', '0.2', outPath)
  const r = await runFfmpeg({ args, ffmpeg, totalMs, onProgress })
  if (!r.ok) throw new Error(r.err)
}

// ---- 本机媒体类型兜底（ADR-0296，发版 review #5）----
// 插件侧 src/knowledge/media-kind.ts 的扩展名白名单是唯一事实源；本文件是独立 Node
// 工具、不能 import TS，这里只留音声后缀一份（改那边记得同步）。认不出按视频，旧行为不变。
const LOCAL_AUDIO_EXTS = new Set([
  'mp3', 'm4a', 'aac', 'wav', 'flac', 'ogg', 'oga', 'opus', 'wma', 'ape', 'amr', 'aiff', 'aif', 'wv',
])
function guessLocalKind(filePath) {
  const ext = path.extname(String(filePath || '')).slice(1).toLowerCase()
  return LOCAL_AUDIO_EXTS.has(ext) ? 'audio' : 'video'
}

async function runLocal(task, deps = {}) {
  resetAbort()
  const conf = { ...(deps.conf || {}), ...((task && task.options) || {}) }
  const ffmpeg = deps.ffmpeg || conf.ffmpegPath || 'ffmpeg'
  const ffprobe = deps.ffprobe || conf.ffprobePath || 'ffprobe'
  const py = deps.py || conf.pythonPath
  const engine = resolveEngine(conf.engine)
  const model = engine === 'faster-whisper' ? (conf.whisperModel || 'small') : ''
  const runPythonImpl = deps.runPythonImpl || runPython
  // 探测/抽音轨的注入点（仅测试用：CI 没有 ffmpeg 二进制，单测打桩）
  const probeImpl = deps.probeDurationImpl || probeDuration
  const extractImpl = deps.extractAudioImpl || extractAudio
  const trimImpl = deps.trimImpl || trimVideo
  const onStep = deps.onStep || (() => {})
  const onProgress = deps.onProgress || (() => {})
  const onInfo = deps.onInfo || (() => {})
  const tmpDir = deps.tmpDir || fs.mkdtempSync(path.join(os.tmpdir(), 'bili-dl-local-'))
  const opts = (task && task.options) || {}
  // 进度行节流：与 runBatch 同一口径（每阶段 ≤300ms 一行）
  const lastPgAt = {}
  const pg = p => {
    const now = Date.now()
    if (now - (lastPgAt[p.phase] || 0) < 300) return
    lastPgAt[p.phase] = now
    onProgress(p)
  }

  const local = (task && task.local) || {}
  const inPath = String(local.path || '').trim()
  if (!inPath) throw new Error('缺少本地文件路径')
  if (!fs.existsSync(inPath)) throw new Error(`找不到文件：${inPath}（可能已被移动或删除）`)
  // 显式 kind 优先；缺省/手改数据按文件名判定，别把播客记成影像（发版 review #5）
  const kind = local.kind === 'audio' || local.kind === 'video' ? local.kind : guessLocalKind(inPath)
  const name = path.basename(inPath)
  const title = name.replace(/\.[^.]+$/, '')

  onStep('读取中')
  const mediaDur = await probeImpl(inPath, ffprobe)
  if (!mediaDur || !(mediaDur > 0)) {
    throw new Error('读不出这个文件的时长——可能不是音视频文件，或 ffprobe 不可用（设置面板「外部工具」里可填路径）')
  }
  // 起止（与 runBatch 同口径：两端都有值才切；非法/越界按整片或钳制）
  let s = 0
  let e = mediaDur
  const hasRange = task.start != null && task.end != null &&
    String(task.start).trim() !== '' && String(task.end).trim() !== ''
  if (hasRange) {
    const start = parseTimeInput(task.start)
    const end = parseTimeInput(task.end)
    if (start === null || end === null) throw new Error('起止时间格式错误（HH:MM:SS.S / MM:SS / 秒）')
    s = Math.max(0, start)
    e = Math.min(mediaDur, end)
    if (e - s < 0.1) { s = 0; e = mediaDur }
  }
  const segDur = e - s
  // 解析信息回传（[bz-info] 行）：标题/时长/类型；本机任务没有 UP 主与 BV 号，url 留空
  try {
    onInfo({ title, uploader: '', bvid: '', url: '', duration: mediaDur, kind })
  } catch { /* 信息回传失败不阻断流程 */ }

  onStep('提取音轨中')
  const wavPath = path.join(tmpDir, 'local-audio.wav')
  try {
    await extractImpl({
      inPath, outPath: wavPath, ffmpeg, start: s, end: e, totalMs: segDur * 1000,
      onProgress: p => pg({ phase: 'extract', pct: Number.isFinite(p.percent) ? p.percent : null }),
    })
  } catch (err) {
    const m = String((err && err.message) || err)
    if (/无法启动 ffmpeg|ENOENT/i.test(m)) {
      throw new Error(`提取音轨失败：找不到 ffmpeg（${lastLine(m)}）——请到设置面板「外部工具」填 ffmpeg 路径，或把 ffmpeg 放进 PATH`)
    }
    throw new Error(`提取音轨失败：${lastLine(m) || m}`)
  }

  onStep('转文字中')
  if (!py) throw new Error('转文字失败：未配置 pythonPath——请在设置面板「外部工具」填 python 路径（或直接写 python 走 PATH）')
  let raw = ''
  let doneFiles = 0
  try {
    await runPythonImpl({
      py, engine, modelsDir: String(conf.modelsDir || '').trim(), args: [model, wavPath],
      onChunk: chunk => {
        raw += chunk
        doneFiles += (String(chunk).match(/\x1e[^\x1f]*\x1f\x1f/g) || []).length
        pg({ phase: 'transcribe', pct: doneFiles >= 1 ? 100 : null })
      },
    })
  } catch (err) {
    const m = (err && err.message) || err
    if (/无法启动 Python|ENOENT/i.test(String(m))) {
      throw new Error(`转文字失败：找不到 Python（${lastLine(String(m))}）——设置面板「外部工具」填 python 路径，或把 python 放进 PATH`)
    }
    if (engine === 'faster-whisper') {
      throw new Error(`转文字失败：${m}（请确认 faster-whisper 环境已安装：目标 Python 已 pip install faster-whisper）`)
    }
    throw new Error(`转文字失败：${m}（请确认 funasr 环境已安装：目标 Python 已 pip install funasr torch torchaudio）`)
  }
  const units = parseTranscriptUnits(raw)
  const byFile = new Map(units.map(u => [path.resolve(u.file), u.text]))
  const transcript = (byFile.get(path.resolve(wavPath)) || '').trim()
  if (!transcript) {
    throw new Error(engine === 'faster-whisper'
      ? '转文字未产出文本（文件可能没有语音，或请确认 faster-whisper 环境可用、模型正常加载）'
      : '转文字未产出文本（文件可能没有语音，或请确认 funasr 环境可用、SenseVoice 模型正常加载）')
  }
  // 转录临时文件：写系统临时目录（CLI 退出后插件仍需读取）
  const transcriptTemp = path.join(
    os.tmpdir(),
    `bili-dl-transcript-local-${Date.now()}-${Math.random().toString(36).slice(2)}.txt`,
  )
  fs.writeFileSync(transcriptTemp, transcript, 'utf8')

  // 交付：保留原件 = 复制一份进交付目录（重名加序号），base 路径回传 vault 相对；
  // keepVideo=false 就只转文字、不复制（笔记逐字保留，但没有可点的媒体）
  const keepVideo = !(opts.keepVideo === false)
  let finalPath = null
  if (keepVideo) {
    onStep('交付中')
    const outOverride = String(opts.outputDir || '').trim()
    if (!conf.outputDir && !outOverride) throw new Error('交付目录未配置（rc outputDir 或 options.outputDir），请在插件设置里填写')
    const outDirAbs = outOverride ? path.resolve(outOverride) : path.resolve(conf.outputDir)
    fs.mkdirSync(outDirAbs, { recursive: true })
    finalPath = uniquePath(path.join(outDirAbs, name))
    // 切片任务交付的必须是「那一段」，不是整片：抽音轨已按 s/e 切过、逐字稿只覆盖片段，
    // 整片复制进库会让笔记里嵌的媒体和正文对不上（发版 review #3）。裁切与校验复用
    // runBatch 同一套 trimVideo（copy 优先、时长校验不过自动重编码），注入点留给测试。
    const needTrim = s > 0 || e < mediaDur
    if (needTrim) {
      const clipPath = path.join(tmpDir, 'local-clip' + (path.extname(inPath) || '.mp4'))
      try {
        await trimImpl({
          inPath, outPath: clipPath, ffmpeg, ffprobe, start: s, end: e, crf: null,
          totalMs: (e - s) * 1000,
          onProgress: p => pg({ phase: 'trim', pct: Number.isFinite(p.percent) ? p.percent : null }),
        })
      } catch (err) {
        throw new Error(`交付片段失败：${lastLine(String((err && err.message) || err))}`)
      }
      fs.copyFileSync(clipPath, finalPath)
    } else {
      fs.copyFileSync(inPath, finalPath)
    }
  }

  return {
    transcript: transcriptTemp,
    video: finalPath ? vaultRel(finalPath, conf.vaultPath) : null,
    transcriptPath: transcriptTemp,
    videoPath: finalPath,
    title,
    bvid: '',
    duration: mediaDur,
    kind,
  }
}

async function runBatch(task, deps = {}) {
  resetAbort()   // 全局中止标志复位（server resetTask 同规）
  // ADR-0296：带 local 的任务走本机文件分支（不下载、不分 P、不压缩视频本体）
  if (task && task.local && typeof task.local === 'object') return runLocal(task, deps)
  // conf 缺省 = rc（调用方读入），task.options（bz 文献盒设置全量下发）并入 conf——
  // 让 options 里的 vaultPath/ffmpegPath/ffprobePath/pythonPath/engine/whisperModel/cacheDir/cacheRetentionDays/outputDir 覆盖 rc 兜底
  const conf = { ...(deps.conf || {}), ...((task && task.options) || {}) }
  const cookie = deps.cookie || null
  const fetchJson = deps.fetchJson || fetchJsonImpl
  const get = deps.get
  const ffmpeg = deps.ffmpeg || conf.ffmpegPath || 'ffmpeg'
  const ffprobe = deps.ffprobe || conf.ffprobePath || 'ffprobe'
  const py = deps.py || conf.pythonPath
  // 模型缓存根目录（可选，bz 设置「模型目录」下发）：空 → 跟随 Python 环境默认
  const modelsDir = String(conf.modelsDir || '').trim()
  // 转写引擎与档位（issue 444）：engine 缺省 sensevoice；档位仅 faster-whisper 消费——
  // args 形状两引擎一致（argv[1] 档位，SenseVoice 忽略），打桩与解析零分叉
  const engine = resolveEngine(conf.engine)
  const model = engine === 'faster-whisper' ? (conf.whisperModel || 'small') : ''
  const runPythonImpl = deps.runPythonImpl || runPython
  const onStep = deps.onStep || (() => {})
  const onProgress = deps.onProgress || (() => {})
  // 进度行节流：各环 150ms 级高频事件聚合为每阶段 ≤300ms 一行（[bz-p] 协议行，插件逐行解析驱动行内进度）。
  // 按 phase 独立计时——快速衔接的阶段（如缓存命中后转写→AI）互不吞行，跨阶段进度不会丢失。
  const lastPgAt = {}
  const pg = p => {
    const now = Date.now()
    if (now - (lastPgAt[p.phase] || 0) < 300) return
    lastPgAt[p.phase] = now
    onProgress(p)
  }
  const tmpDir = deps.tmpDir || fs.mkdtempSync(path.join(os.tmpdir(), 'bili-dl-batch-'))

  const url = String((task && task.url) || '').trim()
  if (!url) throw new Error('缺少 url（B站视频链接或 BV 号）')

  // ① 解析
  onStep('解析中')
  const info = await parseVideo({ url, cookie, fetchJson })

  // ② 下载（缓存命中检测与回写，同 /api/download）
  onStep('下载中')
  const bvid = extractBv(url)
  // 解析信息回传（[bz-info] 行，ADR-0067）：标题/UP主 供插件落库、面板行内以「文字+链接」展示
  const onInfo = deps.onInfo || (() => {})
  try {
    onInfo({
      title: info.title || '', uploader: info.uploader || '',
      bvid, url: bvid ? `https://www.bilibili.com/video/${bvid}` : url, duration: info.duration || 0,
    })
  } catch { /* 信息回传失败不阻断流程 */ }
  // 分P 选择（task.page 1 起，ADR-0067）：越界/缺省/非数字 → 第 1 P；cid 随 P 变 → 按 P 独立缓存键
  const pageNum = Number(task && task.page)
  const selPage = Number.isFinite(pageNum) && pageNum >= 1 ? (info.pages || [])[pageNum - 1] : null
  const playCid = selPage && selPage.cid ? selPage.cid : info.cid
  // 清晰度设置项（task.options.quality）：具体档位数字串（720/1080/480/360…）精确命中；
  // highest/缺省跟随 parse 最高可用（ADR-0133：档位从 720/1080 两档扩展为任意数字串）
  const qOpt = task && task.options ? task.options.quality : undefined
  const qNum = /^\d+$/.test(String(qOpt || '')) ? Number(qOpt) : 0
  const height = qNum > 0 ? qNum : (deps.quality || info.maxHeight)
  const cachedPath = cachePath(conf, cacheKey(bvid, playCid, height))
  const originalPath = path.join(tmpDir, `bili_${Date.now()}.mp4`)
  if (fs.existsSync(cachedPath)) {
    fs.copyFileSync(cachedPath, originalPath)
  } else {
    await downloadVideo({
      url, cookie, height, cid: playCid, outPath: originalPath, ffmpeg, fetchJson, get,
      onProgress: p => pg({ phase: 'download', pct: Number.isFinite(p.percent) ? p.percent : null }),
    })
    // 未命中下载完成后回写缓存（剪辑/压缩件不进缓存）
    try { fs.mkdirSync(path.dirname(cachedPath), { recursive: true }); fs.copyFileSync(originalPath, cachedPath) } catch {}
  }

  // 时长口径基准：B 站 view API 的 duration 是整数秒（常见向上取整），与码流实际时长有 <1s 的
  // 系统性差值。整片压缩拿 API 时长做 -to 与校验，会因超出 0.5s 容差被判「压缩失败」
  // （实测 BV1tK4E6KE1B：API 378s / 码流 377.301769s，差 0.698s）。以下载产物 ffprobe 实测为准，
  // 读不到才退回选中分 P 的时长，最后用 API 总时长兜底。
  let mediaDur = await probeDuration(originalPath, ffprobe)
  if (!mediaDur || !(mediaDur > 0)) mediaDur = (selPage && selPage.duration) || info.duration

  // ③ 剪辑（起止都有值才跑；parseTimeInput 转秒；越界/非法区间 clampSeg 同规 → 按整片）
  let seg = null
  let srcForDeliver = originalPath
  let resumeClipUsed = false   // 断点续跑命中剪辑缓存：交付后不得删缓存件
  let resumeCompressUsed = false   // 断点续跑命中压缩缓存：交付后不得删缓存件
  let srcDur = mediaDur   // 压缩/转文字用的源时长（剪辑后为段长，整片为全片实测时长）
  // 断点续跑区间键（ADR-0067）：无剪辑/整片 → [0, mediaDur]；剪辑 → [start, end]
  let rStart = 0
  let rEnd = mediaDur
  const hasRange = task.start != null && task.end != null &&
    String(task.start).trim() !== '' && String(task.end).trim() !== ''
  if (hasRange) {
    const start = parseTimeInput(task.start)
    const end = parseTimeInput(task.end)
    if (start === null || end === null) throw new Error('起止时间格式错误（HH:MM:SS.S / MM:SS / 秒）')
    let s = Math.max(0, start)
    let e = Math.min(mediaDur, end)
    if (e - s < 0.1) { s = 0; e = mediaDur }
    seg = { start: s, end: e, full: !(s > 0 || e < mediaDur) }
    if (!seg.full) {
      rStart = s
      rEnd = e
      srcDur = e - s
      onStep('剪辑中')
      // 断点续跑：剪辑件留存（resume-clip-*.mp4），命中即跳过 ffmpeg，从下一环继续
      const clipCache = resumeClipPath(conf, bvid, playCid, height, s, e)
      if (fs.existsSync(clipCache)) {
        srcForDeliver = clipCache
        resumeClipUsed = true
      } else {
        const clipPath = path.join(tmpDir, `bili_${Date.now()}_clip.mp4`)
        // crf=null：流复制优先，ffprobe 校验不过自动重编码兜底（不压缩）
        await trimVideo({
          inPath: originalPath, outPath: clipPath, ffmpeg, ffprobe, start: s, end: e, crf: null, totalMs: (e - s) * 1000,
          onProgress: p => pg({ phase: 'trim', pct: Number.isFinite(p.percent) ? p.percent : null }),
        })
        srcForDeliver = clipPath
        try { fs.mkdirSync(path.dirname(clipCache), { recursive: true }); fs.copyFileSync(clipPath, clipCache) } catch {}
      }
    }
  }

  // ③.5 压缩（缺省开，用户拍板 ticket 136；crf 默认 23、钳制 18-28；断点续跑：压缩件留存 resume-compress-*.mp4）
  const opts = (task && task.options) || {}
  const compressEnabled = opts.compress !== false
  const crf = Math.min(28, Math.max(18, Number(opts.crf) || 23))
  /** 实际采纳压缩件（压缩回退时为 false——交付文件名不带 _crf 标记；断点续跑命中压缩缓存恒为 true） */
  let compressedAdopted = false
  if (compressEnabled) {
    onStep('压缩中')
    const compressCache = resumeCompressedPath(conf, bvid, playCid, crf, rStart, rEnd)
    if (fs.existsSync(compressCache)) {
      srcForDeliver = compressCache
      resumeCompressUsed = true
      compressedAdopted = true
    } else {
      const prev = srcForDeliver
      const compressPath = path.join(tmpDir, `bili_${Date.now()}_crf${crf}.mp4`)
      await trimVideo({ inPath: srcForDeliver, outPath: compressPath, ffmpeg, ffprobe, start: 0, end: srcDur, crf, totalMs: srcDur * 1000, onProgress: p => pg({ phase: 'compress', pct: Number.isFinite(p.percent) ? p.percent : null }) })
      // 压缩回退（用户拍板；原网页版旧有、CLI 迁移时移除，本次补回）：压缩件体积严格大于压缩输入（原件/剪辑件）
      // → 压缩无收益，丢弃压缩件、沿用输入交付（不写压缩缓存、文件名不带 _crf 标记）；stat 异常保守采纳压缩件。
      if (needsCompressFallback(prev, compressPath)) {
        try { fs.unlinkSync(compressPath) } catch {}
        srcForDeliver = prev
      } else {
        // 压缩消费了中间剪辑临时件（非原件、非缓存件）→ 立即删，避免临时目录泄漏
        if (prev !== originalPath && !resumeClipUsed) { try { fs.unlinkSync(prev) } catch {} }
        srcForDeliver = compressPath
        compressedAdopted = true
        try { fs.mkdirSync(path.dirname(compressCache), { recursive: true }); fs.copyFileSync(compressPath, compressCache) } catch {}
      }
    }
  }

  // ④ 转文字（断点续跑：转写稿留存 resume-transcript-*.txt，命中即跳过 python，从下一环继续）
  onStep('转文字中')
  if (!py) throw new Error('转文字失败：未配置 pythonPath——请在 bz 插件文献盒设置「Python 路径」填 python（一般装了 Python 即可，spawn 走系统 PATH），或填绝对路径（Windows 命令提示符运行 where python 可查）')
  const transPath = resumeTranscriptPath(conf, bvid, playCid, rStart, rEnd)
  let transcript = ''
  if (fs.existsSync(transPath)) {
    transcript = String(fs.readFileSync(transPath, 'utf8') || '').trim()
  } else {
    let raw = ''
    let doneFiles = 0
    try {
      await runPythonImpl({
        py, engine, modelsDir, args: [model, srcForDeliver],
        onChunk: s => {
          raw += s
          // 完成哨兵（\x1e<file>\x1f\x1f）计数 → 文件级进度（当前单文件：0→100 跳变，诚实不假报）
          doneFiles += (String(s).match(/\x1e[^\x1f]*\x1f\x1f/g) || []).length
          pg({ phase: 'transcribe', pct: doneFiles >= 1 ? 100 : null })
        },
      })
    } catch (err) {
      const m = (err && err.message) || err
      // 找不到 Python（可执行名不在 PATH / 绝对路径不存在）→ 引导填写方式，不误导成转写环境未装
      if (/无法启动 Python|ENOENT/i.test(String(m))) {
        throw new Error(`转文字失败：找不到 Python（${lastLine(String(m))}）——文献盒设置「Python 路径」填 python 即可（走系统 PATH），或填绝对路径（Windows 命令提示符运行 where python 可查）`)
      }
      // 环境引导按引擎分口径（issue 444）：funasr / faster-whisper 各自的 pip 安装引导
      if (engine === 'faster-whisper') {
        throw new Error(`转文字失败：${m}（请确认 faster-whisper 环境已安装：目标 Python 已 pip install faster-whisper）`)
      }
      throw new Error(`转文字失败：${m}（请确认 funasr 环境已安装：目标 Python 已 pip install funasr torch torchaudio）`)
    }
    const units = parseTranscriptUnits(raw)
    const byFile = new Map(units.map(u => [path.resolve(u.file), u.text]))
    transcript = (byFile.get(path.resolve(srcForDeliver)) || '').trim()
    if (!transcript) {
      throw new Error(engine === 'faster-whisper'
        ? '转文字未产出文本（视频可能无语音，或请确认 faster-whisper 环境可用、模型正常加载）'
        : '转文字未产出文本（视频可能无语音，或请确认 funasr 环境可用、SenseVoice 模型正常加载）')
    }
    try { fs.writeFileSync(transPath, transcript, 'utf8') } catch {}
  }

  // ⑤ 转录临时文件：转录全文 UTF-8 写系统临时目录（非批次临时目录——CLI 退出后插件仍需读取），返回绝对路径
  const transcriptTemp = path.join(os.tmpdir(), `bili-dl-transcript-${resumeKey(bvid, playCid, rStart, rEnd)}-${Date.now()}-${Math.random().toString(36).slice(2)}.txt`)
  fs.writeFileSync(transcriptTemp, transcript, 'utf8')

  // ⑥ 交付：文件移入 outputDir（copyFileSync + unlink，exFAT 兼容；重名 uniquePath 加序号）；
  //    输出目录可被 task.options.outputDir 覆盖；「保留视频原件」关（keepVideo=false）→ 整步跳过，
  //    video 结果 null（转录临时文件仍产出——插件据此生成文献笔记）。
  const keepVideo = !(opts.keepVideo === false)
  let finalPath = null
  if (keepVideo) {
    onStep('交付中')
    const outOverride = String(opts.outputDir || '').trim()
    if (!conf.outputDir && !outOverride) throw new Error('交付目录未配置（rc outputDir 或 options.outputDir），请在 bz 插件文献盒设置中填写')
    const outDirAbs = outOverride ? path.resolve(outOverride) : path.resolve(conf.outputDir)
    fs.mkdirSync(outDirAbs, { recursive: true })
    const name = buildFileName({
      title: info.title, bv: bvid,
      page: selPage && pageNum > 1 ? pageNum : '',   // 第 2 P 起文件名带 _N
      trimmed: seg ? !seg.full : false,
      start: seg ? seg.start : 0, end: seg ? seg.end : mediaDur,
      duration: mediaDur, compressed: compressedAdopted, crf,
    })
    finalPath = uniquePath(path.join(outDirAbs, name))
    fs.copyFileSync(srcForDeliver, finalPath)
    if (srcForDeliver !== originalPath && !resumeClipUsed && !resumeCompressUsed) { try { fs.unlinkSync(srcForDeliver) } catch {} }   // 剪辑/压缩临时件已交付，删（缓存件不删）
  }

  return {
    transcript: transcriptTemp,
    video: finalPath ? vaultRel(finalPath, conf.vaultPath) : null,
    transcriptPath: transcriptTemp,
    videoPath: finalPath,
    title: info.title, bvid, duration: mediaDur,
    // 分 P 数：简报据此判断实测时长能不能覆盖投稿列表口径（多 P 的列表时长是全部 P 的总长）
    pageCount: (info.pages || []).length || 1,
  }
}

/* 简报用哪个时长（2026-11-08 review）：多 P 视频的投稿列表时长是全部 P 的总长，而简报只转写
 * 第 1 P——拿实测时长覆盖会把「3 小时课程」显示成「20 分钟」。单 P 才用实测（修正 API 整数秒
 * 与码流 <1s 的系统性差值）；列表没给时长时也只能信实测。 */
function briefDuration(listDur, mediaDur, pageCount) {
  const list = Number(listDur) || 0
  if (!mediaDur) return list
  return (Number(pageCount) || 1) <= 1 || !list ? mediaDur : list
}

// ---- 每日简报批处理（--brief，issue 263）：runBrief ----
// 契约（与 bz 插件「每日简报」对齐，cli.js --brief 调用）：
//   task = { items?, ups?, known?, backfill?, limit?, options }
//   **发现交给本工具**（bili-dl 已有 wbi 签名与 Cookie，守护不必再实现一遍）：
//     ups = 深度名单（uid 字符串或 {mid,name}），backfill = 每 UP 回溯条数（缺省 10，首次启用口径）；
//     逐 UP 拉投稿列表 → 剔除 known（守护传入，来自 news.json briefs 已有 bvid）→ 汇成待处理池。
//     items 直传（[{bvid,title,duration,pubdate}]）时不做发现（手动/测试用）。
//   limit（缺省 3）：单次 spawn 最多处理条数，剩余由守护下轮继续（ADR-0119 §10 分轮消化）。
//   逐条：**字幕优先**（getCid → getSubtitle）→ 命中即把字幕全文落转录临时文件（source='subtitle'）；
//     无字幕 / **字幕可信度校验不过** → 复用 runBatch（keepVideo:false / compress:false / quality:'720'）
//     下载转写（复用其缓存与断点续跑），取其 transcriptPath（source='transcript'），
//     校验不过时额外回报 subtitleRejected 原因。**单条失败不阻断整批**，记入 fail 并继续下一条。
//   onItem(i, n, bvid)：条级进度（调用方可据此打「第 i/N 条」行）；onInfo(info)：每条一次（[bz-info] 语义）。
// 返回 { ok: [{bvid,title,source,transcriptPath,duration,pubdate,upMid,upName,subtitleRejected?}],
//        fail: [{bvid,reason}] }（ups 发现失败时 bvid 为空串，reason 注明 UP）
async function runBrief(task, deps = {}) {
  resetAbort()
  const conf = { ...(deps.conf || {}), ...((task && task.options) || {}) }
  const cookie = deps.cookie || null
  const fetchJson = deps.fetchJson || fetchJsonImpl
  const onStep = deps.onStep || (() => {})
  const onItem = deps.onItem || (() => {})
  const onInfo = deps.onInfo || (() => {})
  const limit = Math.max(1, Number(task && task.limit) || 3)
  const known = new Set((Array.isArray(task && task.known) ? task.known : []).map(u => String(u)))
  const ok = []
  const fail = []
  const ups = (Array.isArray(task && task.ups) ? task.ups : [])
    .map(u => (u && typeof u === 'object'
      ? { mid: String(u.mid || '').trim(), name: String(u.name || '') }
      : { mid: String(u || '').trim(), name: '' }))
    .filter(u => u.mid)
  let pool
  if (ups.length) {
    const backfill = Math.max(1, Number(task && task.backfill) || 10)
    pool = []
    onStep('拉取投稿列表')
    for (const up of ups) {
      try {
        const vids = await getUpVideos({ mid: up.mid, cookie, fetchJson, ps: backfill })
        for (const v of vids) {
          if (known.has(v.bvid)) continue
          pool.push({ ...v, upMid: up.mid, upName: v.author || up.name })
        }
      } catch (err) {
        fail.push({ bvid: '', reason: `UP ${up.mid} 投稿列表拉取失败：${(err && err.message) || String(err)}` })
      }
    }
  } else {
    // items 直传 = 显式指定（手动重跑/调试）：**不按 known 过滤**，否则错误条目无法手动重跑
    pool = (Array.isArray(task && task.items) ? task.items : []).filter(it => it && it.bvid)
  }
  const batch = pool.slice(0, limit)
  for (let i = 0; i < batch.length; i++) {
    const it = batch[i]
    const bvid = String(it.bvid)
    onItem(i + 1, batch.length, bvid)
    const info = {
      title: it.title || '', uploader: it.upName || '',
      bvid, url: `https://www.bilibili.com/video/${bvid}`,
      duration: Number(it.duration) || 0,
    }
    try {
      onStep('字幕中')
      const cid = await getCid({ bvid, cookie, fetchJson })
      const sub = cid ? await getSubtitle({ bvid, cid, cookie, fetchJson, duration: info.duration }) : null
      let text = ''
      let source = 'subtitle'
      const subtitleRejected = (sub && sub.rejected) || ''
      if (subtitleRejected) onStep('字幕存疑，改转写')
      if (sub && sub.text && !subtitleRejected) {
        text = sub.text
      } else {
        source = 'transcript'
        const r = await runBatch(
          {
            url: `https://www.bilibili.com/video/${bvid}`, start: null, end: null,
            options: { ...((task && task.options) || {}), keepVideo: false, compress: false, quality: '720' },
          },
          { ...deps, conf, onStep, onInfo: () => {} },   // 内层不重复打 [bz-info]（外层逐条统一打）
        )
        try { text = String(fs.readFileSync(r.transcriptPath, 'utf8') || '').trim() } catch { text = '' }
        try { fs.unlinkSync(r.transcriptPath) } catch {}   // 转录临时件用后即删（内容随即落简报缓存）
        info.duration = briefDuration(info.duration, r.duration, r.pageCount)   // 多 P 保留列表总长，见 briefDuration
        if (!info.title && r.title) info.title = r.title
      }
      if (!text) throw new Error('未产出转录文本')
      // 转录全文落**缓存目录**（`resume-` 前缀 → cleanupCache 按 cacheRetentionDays 自然回收）：
      // 插件读它产 AI 要点，并在保留期内渲染「可展开转录稿」；过期后文件消失、该区自动隐藏。
      // （不落系统临时目录——插件可能在数小时后才读到，且需受保留期管理。）
      const transcriptPath = path.join(getCacheDir(conf), `resume-brief-${bvid}.txt`)
      fs.mkdirSync(path.dirname(transcriptPath), { recursive: true })
      fs.writeFileSync(transcriptPath, text, 'utf8')
      onInfo(info)
      ok.push({
        bvid, title: info.title, source, transcriptPath, duration: info.duration,
        pubdate: Number(it.pubdate) || 0,
        upMid: String(it.upMid || ''),
        upName: info.uploader || '',
        ...(subtitleRejected ? { subtitleRejected } : {}),
      })
    } catch (err) {
      fail.push({ bvid, reason: (err && err.message) || String(err) })
    }
  }
  return { ok, fail }
}

module.exports = {
  UA, MIXIN_KEY_ENC_TAB, getMixinKey, fetchJsonImpl, getWbiKeys, wbiSign, getViewInfo, getPlayUrls,
  lastLine, qualityLabel, sanitizeName, extractBv, fmtTime, fmtDuration, fmtSec, parseTimeInput, buildFileName,
  parseVideo, fmtEta, downloadStream, mergeStreams, downloadVideo,
  buildTrimArgs, runFfmpeg, probeDuration, validateClip, trimVideo, needsCompressFallback,
  buildMergeArgs, writeConcatList, mergeSegments,
  loadCookies, saveCookies, readJson, writeJson, uniquePath,
  abortAll, resetAbort, trackProc, runPython, PY_TRANSCRIBE, PY_TRANSCRIBE_SENSEVOICE, resolveEngine, parseTranscriptUnits,
  cacheKey, getCacheDir, cachePath, cleanupCache,
  resumeKey, resumeClipPath, resumeCompressedPath, resumeTranscriptPath,
  vaultRel, decodeBatchArg, runBatch, runLocal, extractAudio,
  getUpVideos, parseLenStr, getCid, getSubtitle, checkSubtitlePlausible, runBrief, briefDuration,
}
